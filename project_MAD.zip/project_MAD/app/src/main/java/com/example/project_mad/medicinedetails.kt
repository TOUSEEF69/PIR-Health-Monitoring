package com.example.project_mad

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MedicineDetailsScreen : AppCompatActivity() {

    private lateinit var tvDetails: TextView
    private lateinit var btnUpdate: MaterialButton

    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val userId: String? get() = auth.currentUser?.uid
    private var medicineId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medicinedetails)

        tvDetails = findViewById(R.id.tvMedicineDetails)
        btnUpdate = findViewById(R.id.btnUpdateDetails)

        medicineId = intent.getStringExtra("medicineId")

        if (medicineId.isNullOrEmpty() || userId.isNullOrEmpty()) {
            Toast.makeText(this, "Medicine ID or User ID is missing", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        loadMedicineDetails()

        btnUpdate.setOnClickListener {
            val intent = Intent(this, AddMedicineScreen::class.java)
            intent.putExtra("medicineId", medicineId)
            startActivity(intent)
        }
    }

    private fun loadMedicineDetails() {
        firestore.collection("users").document(userId!!)
            .collection("medicines").document(medicineId!!)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val name = document.getString("name") ?: "N/A"
                    val dosage = document.getString("dosage") ?: "N/A"
                    val time = document.getString("time") ?: "N/A"
                    val frequency = document.getString("frequency") ?: "N/A"

                    val details = """
                        Name: $name
                        Dosage: $dosage
                        Time: $time
                        Frequency: $frequency
                    """.trimIndent()

                    tvDetails.text = details
                } else {
                    Toast.makeText(this, "No medicine data found", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to load medicine data", Toast.LENGTH_SHORT).show()
            }
    }
}
