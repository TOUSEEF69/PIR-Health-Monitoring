package com.example.project_mad

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class EmailVerificationActivity : AppCompatActivity() {

    private lateinit var btnVerified: Button
    private lateinit var firebaseAuth: FirebaseAuth
    private var currentUser: FirebaseUser? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_emailverification)

        btnVerified = findViewById(R.id.btnVerified)
        firebaseAuth = FirebaseAuth.getInstance()
        currentUser = firebaseAuth.currentUser

        if (currentUser == null) {
            // 🔴 User is not logged in (maybe app was closed or restarted)
            Toast.makeText(this, "User session expired. Please sign in again.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, Login::class.java))
            finish()
            return
        }

        btnVerified.setOnClickListener {
            currentUser = firebaseAuth.currentUser

            currentUser?.reload()?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    if (currentUser!!.isEmailVerified) {
                        // ✅ Email is verified
                        Toast.makeText(this, "Email verified successfully!", Toast.LENGTH_SHORT).show()

                        // Optional: Sign out if you want fresh login
                        firebaseAuth.signOut()

                        // Now go to Login screen
                        val intent = Intent(this, Login::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                    } else {
                        // ❌ Email is NOT verified
                        Toast.makeText(this, "Email not verified yet. Please check your inbox.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // ❌ Reload failed
                    Toast.makeText(this, "Error checking verification status.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
