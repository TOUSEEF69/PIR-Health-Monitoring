package com.example.project_mad.models

data class Reminder(
    val name: String = "",
    val dosage: String = "",
    val time: String = "",
    val frequency: String = ""
)
