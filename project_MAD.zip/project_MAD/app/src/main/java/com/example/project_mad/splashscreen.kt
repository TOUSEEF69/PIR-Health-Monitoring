package com.example.project_mad

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class SplashActivity : AppCompatActivity() {

    private val splashTimeOut: Long = 2000 // 2 seconds

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splashscreen)

        val logoImage = findViewById<ImageView>(R.id.logoImageView)
        val animation = AnimationUtils.loadAnimation(this, R.anim.animation)
        logoImage.startAnimation(animation)

        Handler(Looper.getMainLooper()).postDelayed({

            val currentUser = FirebaseAuth.getInstance().currentUser

            if (currentUser != null) {
                // User is already logged in, go to Dashboard
                startActivity(Intent(this, HomeScreenDashboard::class.java))
            } else {
                // User not logged in, go to Welcome screen
                startActivity(Intent(this, GetStartedActivity::class.java))
            }

            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()

        }, splashTimeOut)
    }
}
