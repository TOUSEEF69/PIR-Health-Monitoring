data class OpenAIRequest(
    val model: String = "gpt-3.5-turbo", // or "gpt-4"
    val messages: List<Message>,
    val temperature: Double = 0.7
)


