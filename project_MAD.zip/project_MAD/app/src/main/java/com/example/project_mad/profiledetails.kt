package com.example.project_mad

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileDetailsActivity : AppCompatActivity() {

    private lateinit var nameTextView: TextView
    private lateinit var ageTextView: TextView
    private lateinit var genderTextView: TextView
    private lateinit var diseaseTextView: TextView
    private lateinit var treatmentTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profiledetails)

        nameTextView = findViewById(R.id.nameTextView)
        ageTextView = findViewById(R.id.ageTextView)
        genderTextView = findViewById(R.id.genderTextView)
        diseaseTextView = findViewById(R.id.diseaseTextView)
        treatmentTextView = findViewById(R.id.treatmentTextView)

        fetchUserProfile()
    }

    private fun fetchUserProfile() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        if (userId == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            return
        }

        val db = FirebaseFirestore.getInstance()
        db.collection("users").document(userId).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    nameTextView.text = document.getString("name") ?: "N/A"
                    ageTextView.text = document.getString("age") ?: "N/A"
                    genderTextView.text = document.getString("gender") ?: "N/A"
                    diseaseTextView.text = document.getString("disease") ?: "N/A"
                    treatmentTextView.text = document.getString("treatment") ?: "N/A"
                } else {
                    Toast.makeText(this, "No profile data found", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to fetch profile: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
}
