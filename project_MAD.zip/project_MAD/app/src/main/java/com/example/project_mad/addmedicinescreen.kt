package com.example.project_mad

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class AddMedicineScreen : AppCompatActivity() {

    private lateinit var etMedicineName: TextInputEditText
    private lateinit var etDosage: TextInputEditText
    private lateinit var etTime: TextInputEditText
    private lateinit var spinnerFrequency: Spinner
    private lateinit var btnSaveMedicine: Button

    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val calendar = Calendar.getInstance()
    private var medicineId: String? = null
    private var isEditing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_addmedicinescreen)

        etMedicineName = findViewById(R.id.etMedicineName)
        etDosage = findViewById(R.id.etDosage)
        etTime = findViewById(R.id.etTime)
        spinnerFrequency = findViewById(R.id.spinnerFrequency)
        btnSaveMedicine = findViewById(R.id.btnSaveMedicine)

        // Setup spinner
        val frequencies = arrayOf("Once Daily", "Twice Daily", "Alternate Days", "Weekly")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, frequencies)
        spinnerFrequency.adapter = adapter

        // Time picker dialog
        etTime.setOnClickListener {
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            TimePickerDialog(this, { _, selectedHour, selectedMinute ->
                calendar.set(Calendar.HOUR_OF_DAY, selectedHour)
                calendar.set(Calendar.MINUTE, selectedMinute)
                etTime.setText(String.format("%02d:%02d", selectedHour, selectedMinute))
            }, hour, minute, true).show()
        }

        // Check if editing an existing medicine
        medicineId = intent.getStringExtra("medicineId")
        if (medicineId != null) {
            isEditing = true
            loadMedicineData(medicineId!!)
        }

        // Save or update medicine
        btnSaveMedicine.setOnClickListener {
            val name = etMedicineName.text.toString().trim()
            val dose = etDosage.text.toString().trim()
            val time = etTime.text.toString().trim()
            val frequency = spinnerFrequency.selectedItem.toString()

            if (name.isNotEmpty() && dose.isNotEmpty() && time.isNotEmpty()) {
                val medicineData = hashMapOf(
                    "name" to name,
                    "dosage" to dose,
                    "time" to time,
                    "frequency" to frequency,
                    "timestamp" to FieldValue.serverTimestamp()
                )

                val userId = auth.currentUser?.uid ?: return@setOnClickListener
                val medicineRef = firestore.collection("users").document(userId).collection("medicines")

                if (isEditing) {
                    medicineRef.document(medicineId!!).update(medicineData as Map<String, Any>)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Medicine updated!", Toast.LENGTH_SHORT).show()
                            setReminder(name, calendar.timeInMillis)
                            finish()
                        }
                } else {
                    medicineRef.add(medicineData).addOnSuccessListener { document ->
                        Toast.makeText(this, "Medicine saved successfully!", Toast.LENGTH_SHORT).show()

                        // Set reminder
                        setReminder(name, calendar.timeInMillis)

                        // Go to details screen
                        val intent = Intent(this, MedicineDetailsScreen::class.java)
                        intent.putExtra("medicineId", document.id)
                        startActivity(intent)
                        finish()
                    }
                }
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadMedicineData(id: String) {
        val userId = auth.currentUser?.uid ?: return
        firestore.collection("users").document(userId).collection("medicines")
            .document(id).get().addOnSuccessListener { doc ->
                etMedicineName.setText(doc.getString("name") ?: "")
                etDosage.setText(doc.getString("dosage") ?: "")
                etTime.setText(doc.getString("time") ?: "")
                val freq = doc.getString("frequency") ?: "Once Daily"
                val index = (spinnerFrequency.adapter as ArrayAdapter<String>).getPosition(freq)
                spinnerFrequency.setSelection(index)
            }
    }

    private fun setReminder(medicineName: String, triggerTime: Long) {
        val dosage = etDosage.text.toString().trim()
        val time = etTime.text.toString().trim()
        val frequency = spinnerFrequency.selectedItem.toString()

        val intent = Intent(this, ReminderScreen::class.java).apply {
            putExtra("medicine_name", medicineName)
            putExtra("dosage", dosage)
            putExtra("time", time)
            putExtra("frequency", frequency)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            medicineName.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
    }
}
