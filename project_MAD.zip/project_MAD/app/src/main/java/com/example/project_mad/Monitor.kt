package com.example.project_mad

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.iomt.OpenAIClient
import com.example.iomt.OpenAIMessage
import com.example.iomt.OpenAIRequest
import com.google.firebase.database.*
import kotlinx.coroutines.launch

class FragmentMonitor : Fragment() {

    private lateinit var tempTextView: TextView
    private lateinit var pulseTextView: TextView
    private lateinit var adviceTextView: TextView
    private lateinit var getAdviceBtn: Button

    private lateinit var database: DatabaseReference

    private var currentTemperature: Float = 0.0f
    private var currentPulse: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val view = inflater.inflate(R.layout.fragment_monitor, container, false)
        initializeViews(view)
        initializeFirebase()
        setupClickListeners()
        startFirebaseDataListener()
        return view
    }

    private fun initializeViews(view: View) {
        tempTextView = view.findViewById(R.id.tempTextView)
        pulseTextView = view.findViewById(R.id.pulseTextView)
        adviceTextView = view.findViewById(R.id.adviceTextView)
        getAdviceBtn = view.findViewById(R.id.getAdviceBtn)
    }

    private fun initializeFirebase() {
        database = FirebaseDatabase.getInstance().reference
    }

    private fun setupClickListeners() {
        getAdviceBtn.setOnClickListener {
            if (currentTemperature > 0 && currentPulse > 0) {
                getAdviceBtn.isEnabled = false
                getAdviceBtn.text = "Getting Advice..."
                getAIAdvice(currentTemperature, currentPulse)
            } else {
                Toast.makeText(requireContext(), "Waiting for sensor data...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startFirebaseDataListener() {
        val sensorRef = database.child("IoMTMonitor").child("SensorData")

        sensorRef.child("temperature").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val temp = snapshot.getValue(Float::class.java) ?: 0.0f
                currentTemperature = temp
                tempTextView.text = "Temperature: %.1f °C".format(temp)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Temp Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })

        sensorRef.child("pulse").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val pulse = snapshot.getValue(Int::class.java) ?: 0
                currentPulse = pulse
                pulseTextView.text = "Pulse: $pulse bpm"
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Pulse Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun getAIAdvice(temp: Float, pulse: Int) {
        val prompt = """
            As a medical assistant, analyze these vital signs and provide health advice:
            
            Temperature: ${temp}°C
            Heart Rate: ${pulse} bpm
            
            Please provide:
            1. Assessment of these vital signs
            2. Specific health recommendations
            3. When to seek medical attention if needed
            
            Keep the advice concise and practical.
        """.trimIndent()

        val api = OpenAIClient.create()
        val request = OpenAIRequest(
            model = "mistralai/mistral-7b-instruct:free",
            messages = listOf(OpenAIMessage("user", prompt)),
            temperature = 0.3,
            max_tokens = 300
        )

        val authKey = "Bearer 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"

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val response = api.getAdvice(
                    authorization = authKey,
                    title = "IoMT Health Advisor",
                    referer = "https://your-iomt-app.com",
                    request = request
                )

                if (response.isSuccessful) {
                    val content = response.body()?.choices?.firstOrNull()?.message?.content
                    adviceTextView.text = content ?: "No advice received from AI."
                } else {
                    adviceTextView.text = "Error: ${response.code()} - ${response.message()}"
                }
            } catch (e: Exception) {
                adviceTextView.text = "Connection Error: ${e.message}"
            } finally {
                getAdviceBtn.isEnabled = true
                getAdviceBtn.text = "Get AI Advice"
            }
        }
    }
}
