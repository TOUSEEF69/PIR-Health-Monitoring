data class OpenRouterResponse(
    val choices: List<Choice>,
    val error: ErrorResponse? = null
)

data class ErrorResponse(
    val message: String
)