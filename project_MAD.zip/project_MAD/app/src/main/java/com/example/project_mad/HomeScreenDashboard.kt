package com.example.project_mad

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.project_mad.fragments.HistoryFragment
import com.example.project_mad.ui.FragmentAiAssistant
import com.example.project_mad.FragmentMonitor
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth

class HomeScreenDashboard : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toolbar: Toolbar
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var profileButton: ImageView
    private lateinit var bottomNavigationView: BottomNavigationView

    companion object {
        private const val EDIT_PROFILE_REQUEST_CODE = 2001
        private const val PREFS_NAME = "profile_prefs"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen_dashboard)

        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)
        toolbar = findViewById(R.id.toolbar)
        bottomNavigationView = findViewById(R.id.bottomNavigationView)

        // Profile header
        val headerView = navigationView.getHeaderView(0)
        val profileImageView = headerView.findViewById<ImageView>(R.id.navHeaderProfileImage)
        val usernameText = headerView.findViewById<TextView>(R.id.navHeaderUsername)
        val emailText = headerView.findViewById<TextView>(R.id.navHeaderEmail)

        val user = FirebaseAuth.getInstance().currentUser
        user?.let {
            emailText.text = it.email ?: "No Email"
            val username = it.email?.substringBefore('@')?.replaceFirstChar { ch -> ch.uppercase() } ?: "User"
            usernameText.text = username

            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val uriString = prefs.getString(it.email, null)
            if (!uriString.isNullOrEmpty()) {
                Glide.with(this)
                    .load(Uri.parse(uriString))
                    .circleCrop()
                    .into(profileImageView)
            } else {
                profileImageView.setImageResource(R.drawable.ic_profile)
            }
        }

        // Drawer toggle setup
        setSupportActionBar(toolbar)
        toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navigationView.setNavigationItemSelectedListener {
            handleNavigationItemSelected(it)
            true
        }

        // Load default fragment
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, HomeFragment())
            .commit()

        bottomNavigationView.setOnItemSelectedListener { item ->
            val selectedFragment = when (item.itemId) {
                R.id.nav_ai_assistant -> FragmentAiAssistant()
                R.id.nav_monitor -> FragmentMonitor()
                R.id.nav_history -> HistoryFragment()
                else -> HomeFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, selectedFragment as Fragment)
                .commit()
            true
        }
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else if (supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack()
        } else {
            super.onBackPressed()
        }
    }

    private fun handleNavigationItemSelected(item: MenuItem) {
        when (item.itemId) {
            R.id.nav_add_medicine -> startActivity(Intent(this, AddMedicineScreen::class.java))
            R.id.nav_set_reminder -> startActivity(Intent(this, ReminderScreen::class.java))
            R.id.nav_medication_history -> showToast("History screen not implemented yet")
            R.id.nav_profile -> startActivity(Intent(this, PatientProfileActivity::class.java))
            R.id.nav_settings -> {
                val intent = Intent(this, EditProfileActivity::class.java)
                startActivityForResult(intent, EDIT_PROFILE_REQUEST_CODE)
            }
            R.id.nav_medicine_detail -> startActivity(Intent(this, MedicineDetailsScreen::class.java))
            R.id.nav_logout -> {
                FirebaseAuth.getInstance().signOut()
                val intent = Intent(this, Login::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == EDIT_PROFILE_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageUriString = data?.getStringExtra("image_uri")
            if (!imageUriString.isNullOrEmpty()) {
                val imageUri = Uri.parse(imageUriString)
                Glide.with(this)
                    .load(imageUri)
                    .override(200, 200)
                    .centerCrop()
                    .circleCrop()
                    .into(findViewById(R.id.navHeaderProfileImage))

                saveProfileImageUri(imageUriString)
            }
        }
    }

    private fun saveProfileImageUri(uriString: String) {
        val emailKey = FirebaseAuth.getInstance().currentUser?.email ?: return
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(emailKey, uriString).apply()
    }
}
