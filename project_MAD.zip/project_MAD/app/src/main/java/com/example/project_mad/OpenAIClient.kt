package com.example.iomt

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

// Data Models
data class OpenAIMessage(val role: String, val content: String)

data class OpenAIRequest(
    val model: String,
    val messages: List<OpenAIMessage>,
    val max_tokens: Int = 512,
    val temperature: Double = 0.7
)

data class Choice(val message: OpenAIMessage)

data class OpenAIResponse(
    val choices: List<Choice>? = null,
    val error: OpenAIError? = null
)

data class OpenAIError(val message: String)

// Retrofit API Interface
interface OpenAIService {
    @POST("chat/completions")
    suspend fun getAdvice(
        @Header("Authorization") authorization: String,
        @Header("X-Title") title: String,
        @Header("Referer") referer: String,
        @Body request: OpenAIRequest
    ): Response<OpenAIResponse>
}

// Retrofit Client Singleton
object OpenAIClient {
    private const val BASE_URL = "https://openrouter.ai/api/v1/"

    private val retrofit: Retrofit by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
    }

    fun create(): OpenAIService = retrofit.create(OpenAIService::class.java)
}