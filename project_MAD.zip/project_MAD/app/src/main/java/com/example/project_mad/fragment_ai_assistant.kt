package com.example.project_mad.ui


import Message
import OpenRouterRequest
import  RetrofitClient
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.project_mad.R
import com.example.project_mad.adapters.TipsAdapter
import com.example.project_mad.models.HealthTip
import com.example.project_mad.models.Prediction
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class FragmentAiAssistant : Fragment() {

    private lateinit var symptomsInput: TextInputEditText
    private lateinit var analyzeButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var resultTitle: TextView
    private lateinit var tipsTitle: TextView
    private lateinit var tipsRecyclerView: RecyclerView

    private val tipsAdapter = TipsAdapter()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_ai_assistant, container, false)

        symptomsInput = view.findViewById(R.id.symptomsInput)
        analyzeButton = view.findViewById(R.id.analyzeButton)
        progressBar = view.findViewById(R.id.progressBar)
        resultTitle = view.findViewById(R.id.resultTitle)
        tipsTitle = view.findViewById(R.id.tipsTitle)
        tipsRecyclerView = view.findViewById(R.id.tipsRecyclerView)

        tipsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        tipsRecyclerView.adapter = tipsAdapter

        analyzeButton.setOnClickListener {
            val symptoms = symptomsInput.text.toString().trim()
            if (symptoms.isNotEmpty()) {
                analyzeSymptoms(symptoms)
            } else {
                Toast.makeText(requireContext(), "Please enter your symptoms", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    private fun analyzeSymptoms(symptoms: String) {
        progressBar.visibility = View.VISIBLE

        val prompt = """
        A user has entered the following symptoms: $symptoms.
        Predict the possible diseases with probabilities, and provide 3 health tips to prevent these.
        Format your answer like this:
        [Disease Prediction]
        - Disease A: 70%
        - Disease B: 30%
        [Health Tips]
        - Tip 1
        - Tip 2
        - Tip 3
    """.trimIndent()

        val request = OpenRouterRequest(
            model = "mistralai/devstral-small:free",
            messages = listOf(Message(role = "user", content = prompt)),
            max_tokens = 1024,
            temperature = 0.3
        )

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.api.analyzeSymptoms(
                    authorization = "Bearer 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",
                    referer = "https://yourappdomain.app",
                    title = "Health Prediction Assistant",
                    request = request
                )

                progressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    val aiText = response.body()?.choices?.firstOrNull()?.message?.content ?: ""
                    displayResult(symptoms, aiText)
                } else {
                    Toast.makeText(requireContext(), "AI response failed", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun displayResult(symptoms: String, aiText: String) {
        resultTitle.visibility = View.VISIBLE
        tipsTitle.visibility = View.VISIBLE
        tipsRecyclerView.visibility = View.VISIBLE

        val splitText = aiText.split("[Health Tips]", ignoreCase = true)
        val predictionText = splitText.getOrNull(0)?.trim() ?: ""
        val tipsSection = splitText.getOrNull(1)?.trim() ?: ""

        val prediction = Prediction(
            date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()),
            symptoms = symptoms,
            result = predictionText
        )

        FirebaseFirestore.getInstance()
            .collection("history")
            .document(prediction.id)
            .set(prediction)

        val tipsList = tipsSection.lines()
            .filter { it.startsWith("-") }
            .map { line -> HealthTip(tip = line.removePrefix("-").trim()) }

        tipsAdapter.submitList(tipsList)

        tipsList.forEach { tip ->
            FirebaseFirestore.getInstance()
                .collection("tips")
                .document(tip.id)
                .set(tip)
        }
    }
}
