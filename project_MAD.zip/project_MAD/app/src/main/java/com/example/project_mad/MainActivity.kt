package com.example.project_mad

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HomeScreen : AppCompatActivity() {

    private lateinit var tvWelcome: TextView
    private lateinit var tvNextPill: TextView
    private lateinit var llTodayMeds: LinearLayout
    private lateinit var btnAddMedicine: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Make sure this points to the correct updated XML

        tvWelcome = findViewById(R.id.tvWelcome)
        tvNextPill = findViewById(R.id.tvNextPill)
        llTodayMeds = findViewById(R.id.llTodayMeds)
        btnAddMedicine = findViewById(R.id.btnAddMedicine)

        // Dummy welcome and next pill
        tvWelcome.text = "Welcome, John"
        tvNextPill.text = "Next Pill: Paracetamol @ 2:00 PM"

        // Dummy medicine list
        val medicineList = listOf(
            "Paracetamol @ 2:00 PM",
            "Ibuprofen @ 5:00 PM",
            "Vitamin C @ 8:00 AM"
        )

        for (medicine in medicineList) {
            val textView = TextView(this).apply {
                text = "• $medicine"
                textSize = 16f
                setPadding(24, 16, 24, 16)
                setTextColor(Color.parseColor("#212121"))
                setBackgroundColor(Color.parseColor("#E0E0E0"))

                val layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                layoutParams.setMargins(0, 0, 0, 12)
                this.layoutParams = layoutParams
            }
            llTodayMeds.addView(textView)
        }

        btnAddMedicine.setOnClickListener {
            val intent = Intent(this, AddMedicineScreen::class.java)
            startActivity(intent)
        }
    }
}
