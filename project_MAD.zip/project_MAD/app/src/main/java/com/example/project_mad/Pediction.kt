package com.example.project_mad.models

data class Prediction(
    val id: String = System.currentTimeMillis().toString(),
    val date: String = "",
    val symptoms: String = "",
    val result: String = ""
)
