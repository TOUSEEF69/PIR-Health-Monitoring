data class Choice(
    val message: Message
)