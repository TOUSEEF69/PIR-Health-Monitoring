package com.example.project_mad

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.project_mad.adapter.ArticleAdapter
import com.example.project_mad.model.NewsResponse
import com.example.project_mad.network.NewsApiService
import com.example.project_mad.network.NewsRetrofitClient
import com.google.firebase.auth.FirebaseAuth
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class HomeFragment : Fragment() {

    private lateinit var articleRecyclerView: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var lastUpdatedText: TextView
    private lateinit var articleAdapter: ArticleAdapter

    private val API_KEY = "45681737a2b84ac6bed4a02e042d6fd4"
    private val DISEASE_PREFS = "disease_pref"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        articleRecyclerView = view.findViewById(R.id.articleRecyclerView)
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout)
        lastUpdatedText = view.findViewById(R.id.lastUpdatedText)

        articleAdapter = ArticleAdapter(mutableListOf())
        articleRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        articleRecyclerView.adapter = articleAdapter

        swipeRefreshLayout.setOnRefreshListener {
            fetchArticles(getUserDiseaseQuery())
        }

        fetchArticles(getUserDiseaseQuery())
        return view
    }

    private fun fetchArticles(query: String) {
        swipeRefreshLayout.isRefreshing = true
        val apiService = NewsRetrofitClient.api
        val call = apiService.getArticlesByQuery(query, API_KEY)

        call.enqueue(object : Callback<NewsResponse> {
            override fun onResponse(call: Call<NewsResponse>, response: Response<NewsResponse>) {
                swipeRefreshLayout.isRefreshing = false
                if (!isAdded) return  // ✅ Prevent crash if Fragment is detached

                if (response.isSuccessful) {
                    val articles = response.body()?.articles ?: emptyList()
                    articleAdapter.updateArticles(articles)
                    updateLastUpdatedTime()
                    if (articles.isEmpty()) showToast("No articles found for \"$query\".")
                } else {
                    showToast("Failed to load articles: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<NewsResponse>, t: Throwable) {
                swipeRefreshLayout.isRefreshing = false
                if (!isAdded) return  // ✅ Prevent crash if Fragment is detached
                showToast("Error fetching articles: ${t.localizedMessage}")
            }
        })
    }

    private fun getUserDiseaseQuery(): String {
        val email = FirebaseAuth.getInstance().currentUser?.email ?: return "health"
        return context?.getSharedPreferences(DISEASE_PREFS, Context.MODE_PRIVATE)
            ?.getString(email, "diabetes") ?: "diabetes"
    }

    @SuppressLint("SetTextI18n")
    private fun updateLastUpdatedTime() {
        val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        val currentTime = sdf.format(Date())
        lastUpdatedText.text = "Last Updated: $currentTime"
    }

    private fun showToast(message: String) {
        context?.let {
            Toast.makeText(it, message, Toast.LENGTH_SHORT).show()
        }
    }


}
