package com.example.project_mad.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.project_mad.R
import com.example.project_mad.models.HealthTip

class TipsAdapter : RecyclerView.Adapter<TipsAdapter.TipsViewHolder>() {

    private val tips = mutableListOf<HealthTip>()

    fun submitList(newTips: List<HealthTip>) {
        tips.clear()
        tips.addAll(newTips)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TipsViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_tip, parent, false)
        return TipsViewHolder(view)
    }

    override fun onBindViewHolder(holder: TipsViewHolder, position: Int) {
        holder.bind(tips[position])
    }

    override fun getItemCount(): Int = tips.size

    class TipsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tipText: TextView = itemView.findViewById(R.id.tipText)

        fun bind(tip: HealthTip) {
            tipText.text = tip.tip
        }
    }
}
