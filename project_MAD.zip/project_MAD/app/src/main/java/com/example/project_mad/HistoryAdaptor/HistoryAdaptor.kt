package com.example.project_mad.adapters

import android.view.*
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.project_mad.R
import com.example.project_mad.models.Prediction

class HistoryAdapter(private val items: List<Prediction>) :
    RecyclerView.Adapter<HistoryAdapter.PredictionViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PredictionViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_prediction, parent, false)
        return PredictionViewHolder(view)
    }

    override fun onBindViewHolder(holder: PredictionViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class PredictionViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val dateText: TextView = view.findViewById(R.id.dateText)
        private val symptomsText: TextView = view.findViewById(R.id.symptomsText)
        private val resultText: TextView = view.findViewById(R.id.resultText)

        fun bind(prediction: Prediction) {
            dateText.text = prediction.date
            symptomsText.text = "Symptoms: ${prediction.symptoms}"
            resultText.text = prediction.result
        }
    }
}
