package com.example.project_mad.fragments

import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.project_mad.R
import com.example.project_mad.models.Prediction
import com.example.project_mad.adapters.HistoryAdapter
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class HistoryFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyState: TextView
    private val predictions = mutableListOf<Prediction>()
    private lateinit var adapter: HistoryAdapter
    private var listener: ListenerRegistration? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_history, container, false)

        recyclerView = view.findViewById(R.id.historyRecyclerView)
        emptyState = view.findViewById(R.id.emptyState)

        adapter = HistoryAdapter(predictions)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        fetchHistory()

        return view
    }

    private fun fetchHistory() {
        val db = FirebaseFirestore.getInstance()
        listener = db.collection("history")
            .addSnapshotListener { snapshot, error ->
                predictions.clear()
                if (error == null && snapshot != null && !snapshot.isEmpty) {
                    for (doc in snapshot.documents) {
                        doc.toObject(Prediction::class.java)?.let {
                            predictions.add(it)
                        }
                    }
                    adapter.notifyDataSetChanged()
                    emptyState.visibility = View.GONE
                } else {
                    emptyState.visibility = View.VISIBLE
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        listener?.remove()
    }
}
