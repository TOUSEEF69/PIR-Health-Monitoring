package com.example.project_mad.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.project_mad.R
import com.example.project_mad.models.Reminder

class ReminderAdapter(
    private val reminders: List<Reminder>,
    private val onEdit: (Reminder) -> Unit,
    private val onDelete: (Reminder) -> Unit
) : RecyclerView.Adapter<ReminderAdapter.ReminderViewHolder>() {

    class ReminderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvReminderName)
        val tvDetails: TextView = view.findViewById(R.id.tvReminderDetails)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEditReminder)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDeleteReminder)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReminderViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.reminder_item, parent, false)
        return ReminderViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReminderViewHolder, position: Int) {
        val reminder = reminders[position]
        holder.tvName.text = reminder.name
        holder.tvDetails.text = "Dosage: ${reminder.dosage}\nTime: ${reminder.time} | ${reminder.frequency}"

        holder.btnEdit.setOnClickListener { onEdit(reminder) }
        holder.btnDelete.setOnClickListener { onDelete(reminder) }
    }

    override fun getItemCount(): Int = reminders.size
}
