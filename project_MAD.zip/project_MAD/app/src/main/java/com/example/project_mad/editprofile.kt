package com.example.project_mad

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File
import java.io.FileOutputStream

class EditProfileActivity : AppCompatActivity() {

    private lateinit var profileImage: ImageView
    private lateinit var uploadImageButton: Button
    private lateinit var nameField: EditText
    private lateinit var ageField: EditText
    private lateinit var genderField: EditText
    private lateinit var diseaseField: EditText
    private lateinit var medicinesField: EditText
    private lateinit var additionalIssuesField: EditText
    private lateinit var doctorHistoryField: EditText
    private lateinit var treatmentField: EditText
    private lateinit var saveButton: Button

    private var selectedImageUri: Uri? = null

    private val firebaseUser = FirebaseAuth.getInstance().currentUser
    private val firestore = FirebaseFirestore.getInstance()

    companion object {
        private const val IMAGE_PICK_CODE = 1001
        private const val PROFILE_IMAGE_FILENAME = "profile_image.png"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editprofile)

        // Initialize views
        profileImage = findViewById(R.id.profileImage)
        uploadImageButton = findViewById(R.id.buttonUploadImage)
        nameField = findViewById(R.id.editName)
        ageField = findViewById(R.id.editAge)
        genderField = findViewById(R.id.editGender)
        diseaseField = findViewById(R.id.editDisease)
        medicinesField = findViewById(R.id.editMedicines)
        additionalIssuesField = findViewById(R.id.editAdditionalIssues)
        doctorHistoryField = findViewById(R.id.editDoctorHistory)
        treatmentField = findViewById(R.id.editTreatment)
        saveButton = findViewById(R.id.buttonSaveProfile)

        // Load image from internal storage if exists
        loadSavedProfileImage()

        // Image picker
        profileImage.setOnClickListener { pickImage() }
        uploadImageButton.setOnClickListener { pickImage() }

        // Save data
        saveButton.setOnClickListener {
            saveProfileData()
        }
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, IMAGE_PICK_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == IMAGE_PICK_CODE && resultCode == Activity.RESULT_OK) {
            selectedImageUri = data?.data

            // Save the image to internal storage
            selectedImageUri?.let { uri ->
                try {
                    val inputStream = contentResolver.openInputStream(uri)
                    val file = File(filesDir, PROFILE_IMAGE_FILENAME)
                    inputStream?.use { input ->
                        FileOutputStream(file).use { output ->
                            input.copyTo(output)
                        }
                    }
                    profileImage.setImageURI(uri)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadSavedProfileImage() {
        val imageFile = File(filesDir, PROFILE_IMAGE_FILENAME)
        if (imageFile.exists()) {
            val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
            profileImage.setImageBitmap(bitmap)
        }
    }

    private fun saveProfileData() {
        val uid = firebaseUser?.uid ?: return

        val disease = diseaseField.text.toString().trim()  // Extract disease for reuse

        // Save user profile data (excluding image, which is saved locally)
        val userData = mapOf(
            "name" to nameField.text.toString().trim(),
            "age" to ageField.text.toString().trim(),
            "gender" to genderField.text.toString().trim(),
            "disease" to disease,
            "medicines" to medicinesField.text.toString().trim(),
            "additional_issues" to additionalIssuesField.text.toString().trim(),
            "doctor_history" to doctorHistoryField.text.toString().trim(),
            "treatment" to treatmentField.text.toString().trim()
        )

        val sharedPrefs = getSharedPreferences("disease_pref", MODE_PRIVATE)
        val editor = sharedPrefs.edit()
        val userEmail = FirebaseAuth.getInstance().currentUser?.email
        if (userEmail != null) {
            editor.putString(userEmail, disease)
            editor.apply()
        }

        // Save data to Firestore
        firestore.collection("users").document(uid)
            .set(userData)
            .addOnSuccessListener {
                Toast.makeText(this, "Profile saved successfully", Toast.LENGTH_SHORT).show()
                finish()  // 🔁 On resume in HomeScreenDashboard will trigger article update
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
