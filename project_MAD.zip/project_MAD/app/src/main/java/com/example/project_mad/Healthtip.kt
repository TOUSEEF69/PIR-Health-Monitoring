package com.example.project_mad.models

data class HealthTip(
    val id: String = System.currentTimeMillis().toString(),
    val tip: String = ""
)
