package com.example.project_mad

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.signature.ObjectKey
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File

class PatientProfileActivity : AppCompatActivity() {

    private lateinit var profileImage: ImageView
    private lateinit var nameView: TextView
    private lateinit var ageView: TextView
    private lateinit var genderView: TextView
    private lateinit var diseaseView: TextView
    private lateinit var medicinesView: TextView
    private lateinit var additionalIssuesView: TextView
    private lateinit var doctorHistoryView: TextView
    private lateinit var treatmentView: TextView

    private val firestore = FirebaseFirestore.getInstance()
    private val firebaseUser = FirebaseAuth.getInstance().currentUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient_profile)

        profileImage = findViewById(R.id.profileImageView)
        nameView = findViewById(R.id.textName)
        ageView = findViewById(R.id.textAge)
        genderView = findViewById(R.id.textGender)
        diseaseView = findViewById(R.id.textDisease)
        medicinesView = findViewById(R.id.textMedicines)
        additionalIssuesView = findViewById(R.id.textAdditionalIssues)
        doctorHistoryView = findViewById(R.id.textDoctorHistory)
        treatmentView = findViewById(R.id.textTreatment)

        loadProfileData()
    }

    private fun loadProfileData() {
        val user = firebaseUser ?: return

        firestore.collection("users").document(user.uid)
            .get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val name = document.getString("name") ?: "N/A"
                    val age = document.getString("age") ?: "N/A"
                    val gender = document.getString("gender") ?: "N/A"
                    val disease = document.getString("disease") ?: ""
                    val medicines = document.getString("medicines") ?: ""
                    val additionalIssues = document.getString("additional_issues") ?: ""
                    val doctorHistory = document.getString("doctor_history") ?: ""
                    val treatment = document.getString("treatment") ?: ""

                    nameView.text = name
                    ageView.text = age
                    genderView.text = gender
                    diseaseView.text = disease.ifEmpty { "N/A" }
                    medicinesView.text = medicines.ifEmpty { "N/A" }
                    additionalIssuesView.text = additionalIssues.ifEmpty { "N/A" }
                    doctorHistoryView.text = doctorHistory.ifEmpty { "N/A" }
                    treatmentView.text = treatment.ifEmpty { "N/A" }

                    // Load profile image locally or from uri (your existing code)
                    loadLocalProfileImageFallback()

                } else {
                    Toast.makeText(this, "No profile found", Toast.LENGTH_SHORT).show()
                    loadLocalProfileImageFallback()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_SHORT).show()
                loadLocalProfileImageFallback()
            }
    }

    private fun loadLocalProfileImageFallback() {
        val file = File(filesDir, "profile_image.png")
        if (file.exists()) {
            Glide.with(this)
                .load(file)
                .override(200, 200)
                .centerCrop()
                .circleCrop()
                .signature(ObjectKey(file.lastModified()))
                .into(profileImage)
        }
    }
}
