package com.example.project_mad

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class Signup : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnSignup: Button
    private lateinit var tvAlreadyAccount: TextView

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        etUsername = findViewById(R.id.etUsername)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnSignup = findViewById(R.id.btnSignup)
        tvAlreadyAccount = findViewById(R.id.tvAlreadyAccount)

        firebaseAuth = FirebaseAuth.getInstance()

        btnSignup.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString()
            val confirmPassword = etConfirmPassword.text.toString()

            if (validateInput(username, email, password, confirmPassword)) {
                firebaseAuth.fetchSignInMethodsForEmail(email)
                    .addOnCompleteListener { task ->
                        val signInMethods = task.result?.signInMethods
                        if (!signInMethods.isNullOrEmpty()) {
                            etEmail.error = "Email is already registered"
                        } else {
                            firebaseAuth.createUserWithEmailAndPassword(email, password)
                                .addOnCompleteListener { signupTask ->
                                    if (signupTask.isSuccessful) {
                                        val user = firebaseAuth.currentUser
                                        user?.sendEmailVerification()?.addOnCompleteListener { verifyTask ->
                                            if (verifyTask.isSuccessful) {
                                                Toast.makeText(this, "Verification email sent. Check your inbox.", Toast.LENGTH_LONG).show()

                                                // ✅ DON'T sign out here; keep the user logged in
                                                val intent = Intent(this, EmailVerificationActivity::class.java)
                                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                                startActivity(intent)
                                                finish()
                                            } else {
                                                Toast.makeText(this, "Failed to send verification email.", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    } else {
                                        Toast.makeText(this, "Signup failed: ${signupTask.exception?.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        }
                    }
            }
        }

        tvAlreadyAccount.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    private fun validateInput(username: String, email: String, password: String, confirmPassword: String): Boolean {
        if (username.isEmpty()) {
            etUsername.error = "Username is required"
            return false
        }

        if (email.isEmpty()) {
            etEmail.error = "Email is required"
            return false
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Enter a valid email"
            return false
        }

        if (password.isEmpty()) {
            etPassword.error = "Password is required"
            return false
        }

        if (password.length < 6 || password.length > 8) {
            etPassword.error = "Password must be 6 to 8 characters"
            return false
        }

        if (!isStrongPassword(password)) {
            etPassword.error = "Password must include uppercase, lowercase, number, special character"
            return false
        }

        if (confirmPassword != password) {
            etConfirmPassword.error = "Passwords do not match"
            return false
        }

        return true
    }

    private fun isStrongPassword(password: String): Boolean {
        val uppercase = Regex("[A-Z]")
        val lowercase = Regex("[a-z]")
        val digit = Regex("[0-9]")
        val specialChar = Regex("[@#\$%^&+=!]")
        return password.contains(uppercase) &&
                password.contains(lowercase) &&
                password.contains(digit) &&
                password.contains(specialChar)
    }
}
