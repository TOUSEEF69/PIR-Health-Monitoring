data class OpenAIResponse(
    val choices: List<Choice>
)




