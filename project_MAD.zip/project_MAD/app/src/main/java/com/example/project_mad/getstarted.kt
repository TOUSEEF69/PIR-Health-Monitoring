package com.example.project_mad

import android.content.Intent
import android.os.Bundle
import android.view.animation.*
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GetStartedActivity : AppCompatActivity() {

    private lateinit var tvWelcomeTitle: TextView
    private lateinit var btnLogin: Button
    private lateinit var btnSignup: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_getstarted)

        // Find views
        tvWelcomeTitle = findViewById(R.id.tvWelcomeTitle)
        btnLogin = findViewById(R.id.btnLogin)
        btnSignup = findViewById(R.id.btnSignup)

        // Create a combined animation: fade in + slide up + slight scale
        val animationSet = AnimationSet(true).apply {
            interpolator = DecelerateInterpolator()
            duration = 1500

            // Fade In
            addAnimation(AlphaAnimation(0f, 1f))

            // Slide Up
            addAnimation(TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, 1f,
                Animation.RELATIVE_TO_SELF, 0f
            ))

            // Scale (Zoom In slightly)
            addAnimation(ScaleAnimation(
                0.9f, 1f, // X from 90% to 100%
                0.9f, 1f, // Y from 90% to 100%
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
            ))
        }

        tvWelcomeTitle.startAnimation(animationSet)

        // Button click actions
        btnLogin.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        btnSignup.setOnClickListener {
           val intent = Intent(this, Signup::class.java)
            startActivity(intent)
        }
    }
}
