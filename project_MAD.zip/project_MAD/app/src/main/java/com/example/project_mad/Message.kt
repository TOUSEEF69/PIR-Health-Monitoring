data class Message(
    val role: String,
    val content: String
)
